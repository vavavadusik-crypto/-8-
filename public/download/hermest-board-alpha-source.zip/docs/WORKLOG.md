# Worklog

## 2026-07-20

- P3.2 research → source cards SHIPPED end-to-end on the free stack: `src/media/research-sources.js` (drafted by headless Claude on the second account per owner directive, reviewed; wikipedia/crossref/arxiv/openlibrary in parallel, fail-open, bounded, deterministic ids) feeds the AI Director, which grounds every card in the canonical source list (invented refs are dropped); the board carries `sources` and cards carry verified `sourceRefs`. Deep bridge debugging along the way: DeepSeek adapter verified live (execCommand input strategy — React textarea drops programmatic value; Enter-fallback submits), reasoning chats (gpt-5-6-thinking, DeepThink) hide the stop button between thinking phases so "stable text" is NOT completion — new `requireJson` option holds until the answer parses as JSON; `/v1` now forwards system messages and per-request options; board-side transport switched to node:http because undici's fetch kills header waits at ~300 s while DeepThink legally thinks longer. LIVE PROOF: «Квантовые компьютеры простыми словами» → 3 crossref sources (wikipedia 429 on a flaky network, fail-open) → DeepSeek directs → 6/6 cards with real citations. Gates: board 240/240 unit + 5/5 media; bridge 20/20.
- P2.9 background cascade WIRED into render-project: scenes without b-roll now go through `createDefaultImageSourceCascade` (FAL first when its key exists, free Pexels photos next; each source fails open to the next with an honest manifest warning) instead of FAL-only — with FAL's balance exhausted the render keeps free photo backgrounds instead of bare frames; availability is now cascade-aware (any configured provider = executable). Bridge got a DeepSeek adapter (drafted by the free deepseek executor via OpenCode, reviewed line-by-line, 19/19 bridge tests) and the bridge service was restarted with 4 providers; Gemini verified LIVE through the bridge («Да, работает.»). Gate: 232/232 unit + 5/5 media.

- PREMIUM MOTION ENGINE SHIPPED (owner directive: «не переделывай видео — оживи существующий дизайн»): every scene now BUILDS ITSELF in front of the viewer instead of appearing as a finished still — staged cascade (chrome bar → kicker → headline → lead → card panel), diagram links draw in via stroke-dashoffset, orbit nodes pop in one by one with labels, active node pulses, progress dots stagger, glows drift, stars twinkle; base styles are the FINAL state with `fill-mode: backwards`, so disabling animation reproduces the previous static frame exactly (owner's acceptance criterion, locked by test). Capture: deterministic per-frame Chrome screenshots — the page freezes all animations at `#t=<ms>` via `document.getAnimations()` (virtual-time-budget does NOT drive CSS animations — verified empirically; scripted pause is byte-deterministic). Playback: `-framerate` image sequences with `tpad=stop_mode=clone` hold + gentle camera push-in (zoompan 1→1.04) on opaque scenes; overlay sequences (transparent PNGs) hold over b-roll/FLUX backgrounds. Manifest schema extended (sequence inputs, hold chains, `#t=` urls; first+last capture command per scene recorded). Gate keeps `HERMEST_SCENE_BUILD_FRAME_LIMIT=6` for speed while production captures the full 2.8 s window at recipe fps. Gate: 219/219 unit + 5/5 media + build + browser smoke.

## 2026-07-19

- P2.3 asset cache SHIPPED: generated FLUX backgrounds are now cached on disk (`src/media/asset-cache.js`, key = sha256(provider+model+style+prompt+size+seed), default `~/.cache/hermest-board/generated-images`, override `HERMEST_ASSET_CACHE_DIR`) — re-rendering the same project makes zero paid provider calls (locked by a counting-mock unit test); cache hits return byte- and provenance-identical results so repeat manifests stay deterministic; entries are sha256-verified on read (tampered → evicted and regenerated); any cache failure fails open to live generation with an honest footage warning. Wired around the FAL adapter in render-project. Gate: 213/213 unit + 5/5 media + build + browser smoke.
- P2.10 BYOK-UX SHIPPED (owner ask: «чтобы люди сами вставляли API»): the local render panel got an "API-ключи (BYOK)" section — per-provider rows (ElevenLabs/FAL/Pexels) with honest status (env / session / не задан), password input, save and clear. Keys live ONLY in the local worker process memory until restart (`src/local-media/provider-keys.js`: printable-ASCII validation, session-vs-environment tracking, env-sourced keys not clearable from UI); loopback-only routes `GET/POST/DELETE /api/local-media/providers*` behind the mutation header; key value never appears in any response, project document, localStorage, or manifest (locked by unit+http+static tests). Live-verified in the browser preview: save fake key → «активен (сессия)» + cleared input, «Убрать» → «не задан», no localStorage leak, no console errors. Gate: 208/208 unit + 5/5 media + build + browser smoke.
- P2.5 Ken Burns drift SHIPPED: static scene backgrounds (FLUX-generated images) now get a slow deterministic camera drift instead of standing dead — four fixed presets (zoom-in, pan right, zoom-out, pan left) cycled by scene index via `zoompan` in the composed graph (`kenBurnsDrift` in `src/media/ffmpeg-args.js`); the text overlay frame stays static and sharp; b-roll video scenes and plain frames are untouched. Manifest schema-lock extended with a dedicated zoompan segment pattern (tampered expressions rejected). Runtime proven by a new keyless integration test: synthetic gradient background → real ffmpeg composed render → probe + byte-identical double run. Gotcha captured: `loudnorm` on pure digital silence (anullsrc) yields −∞ LUFS → NaN → AAC encoder crash — synthetic narration must be a quiet sine. Gate: 201/201 unit + 5/5 media + build + browser smoke.
- P2 b-roll footage port SHIPPED (ADR-003): scenes after the title can now play on-topic background video under a transparent branded overlay frame (owner requirement: "фоновое видео по теме сцены"). Provider-neutral port `src/media/broll-source.js` with the Pexels Videos adapter (free key `HERMEST_PEXELS_API_KEY`; orientation-aware clip selection preferring long-enough clips then coverage; bounded response/clip sizes; key never logged), scene-markup `overlay` mode (transparent body + headline scrim, stars/grid off), transparent Chrome screenshots (`--default-background-color=00000000`, schema-locked), extended `render-composed` ffmpeg graph (`-stream_loop` clip inputs → scale-cover+crop+darken → overlay frame → concat) with per-segment filter validation, and a new `footage` manifest section (license fail-closed, sha256, author/url provenance). Missing key/clip degrades honestly to opaque frames with warnings. Overlay mechanics proven by a live local render (gradient clip + transparent frame + burned subtitles). Gate: 179/179 unit + 3/3 media + build + browser smoke.
- P2 scene composer v1 SHIPPED: scenes now render as branded motion-design frames (dark cosmos, HERMEST BOARD chrome bar, chapter badge, big typography, topic node-diagram, progress dots, caption zone) instead of flat color+drawtext. Pure deterministic markup builder (`src/media/scene-markup.js`, full HTML-escaping of card text, seeded star field, 16:9+9:16 layouts) → headless system Chrome screenshot per scene (`src/media/scene-frames.js`, locked argv schema, PNG magic check, private profile dir) → new `render-composed` ffmpeg path (`buildComposedVideoRenderArgs`: per-scene `-loop` inputs, concat, subtitles; exact manifest argv schema). Honest fallback to legacy color scenes when Chrome is missing (warning + `legacy_color_scenes` qc check). Fixed `file://` run-path redaction so repeat renders stay manifest-identical. Gate: 172/172 unit + 3/3 media (composed, incl. repeat determinism) + build + browser smoke. Visual acceptance samples: `~/Видео/hermest-board-voice-samples/COMPOSED-george-{16x9,9x16}.mp4` (ElevenLabs George voice, full product pipeline).
- P1.3 live smoke CLOSED with a real ElevenLabs key (free tier): three full product renders of the Russian fixture through `renderProject` with `narrationProvider: "elevenlabs"` — voices George/Alice/Aterna (Vadim's custom voice), all ffprobe-valid H.264/AAC MP4s (17.1–19.5 s), zero key leakage in any artifact/manifest (grep-verified), 750/10000 monthly characters used. Samples for subjective acceptance: `~/Видео/hermest-board-voice-samples/elevenlabs-{george,alice,aterna}-ru.mp4`. Context: Vadim REJECTED the Piper medium voices as release quality ("отстой") — Piper stays as the free/offline tier, ElevenLabs (or an equivalent premium adapter) is the release voice path; P1 phase gate now waits on acceptance of the ElevenLabs samples.
- Launched a background adversarial code review (3 lenses: correctness/security/test-honesty + refutation pass) over the whole P1 diff `43bd6c8..266efd6`; confirmed findings will be fixed RED→GREEN before P2 code lands.
- Finalized and committed the execution master plan (`docs/MASTER_PLAN_2026-07-19.md`) and the continuity protocol (`docs/EXECUTION_STATE.md`); closed P0 (merge to `main`, push, tag `v0.3.0-alpha`).
- P1.1: recorded ADR-001 — Piper as default local multilingual TTS, ElevenLabs `eleven_multilingual_v2` as premium BYOK "any language" mode, flite demoted to offline smoke only.
- P1.2: shipped the Piper narration adapter with per-language voice catalog (RU dmitri/irina, EN lessac, ES davefx, DE thorsten, FR siwis), fail-closed availability statuses, argv evidence validated in the manifest.
- Pinned Piper generator noise to zero → repeated synthesis verified byte-identical (sha256), preserving manifest/hash determinism.
- Installed Piper 2023.11.14-2 and all six voice models on the render host; live-synthesized real Russian (both voices) and English WAVs through the project adapter (ffprobe-verified, samples in `~/Видео/hermest-board-voice-samples/`).
- Routed `renderProject` narration through language-aware adapter selection (`brief.language`/`brief.voice`/`brief.narrationProvider`), honest flite fallback when Piper is unavailable.
- Added a provider-neutral narration canonicalization step (ffmpeg → 48 kHz mono PCM) between synthesis and render so any provider's native sample rate meets the pipeline audio contract; command evidence recorded and schema-validated in the manifest; media gate now exercises real Piper narration end to end.
- Full `npm run check` green: 134/134 unit, 2/2 real FFmpeg renders, API smoke, build, browser smoke.
- P1.7 + P1.8: the media gate now renders a Russian fixture (`test/fixtures/russian-board.json`, ru_RU-dmitri voice) alongside the English ones — 3/3 real FFmpeg renders prove language is a parameter, not a hardcode; every integration case asserts the manifest carries narration lineage (provider/language/voice in `tools.tts`), locked at unit level too. **P1 is code-complete**; phase gate now waits only on Vadim's subjective voice acceptance (+ optional ElevenLabs live smoke when a key exists).
- P1.6: board UI got narration controls in the local render panel — project language (RU/EN/ES/DE/FR native Piper + PT/IT/JA/ZH via ElevenLabs), per-language voice catalog (Дмитрий/Ирина for RU), and TTS provider select; `brief` is now part of the project document (starter/normalize/build/apply round-trip, persisted and restored), out-of-matrix languages force the ElevenLabs BYOK provider with an honest hint and reset back to auto-Piper when leaving, explicitly chosen ElevenLabs survives language switches. Verified live in the browser preview (DOM state + localStorage round-trip + reload), zero console errors. Gate green: 152/152 unit + 2/2 media + build + browser smoke.
- P1.5: every render now measures the actual loudness of the produced MP4 (second loudnorm pass, JSON report parsed fail-closed from ffmpeg stderr) and records it in `manifest.qc.loudness` (integrated LUFS / true peak / LRA / threshold + the −16 LUFS target); the measure command is audited in manifest command evidence and schema-validated; integration tests assert the report is present in real renders. Gate green: 152/152 unit + 2/2 media.
- P1.4: narration is now synthesized per scene — each scene's measured (ffprobe) duration drives its storyboard timing (scene = narration + 400 ms padding, never shorter than its own speech), scene WAVs are zero-padded and concatenated sample-exactly in Node (`src/media/wav-concat.js`, deterministic, no dynamic ffmpeg graphs), SRT cues end with the measured speech inside each scene; per-scene tts/canonicalize command evidence lands in the manifest. Live proof: RU demo render (3 scenes, dmitri) — subtitles end exactly with speech, video 16.17 s vs narration 16.15 s; sample at `~/Видео/hermest-board-voice-samples/ru-demo-dmitri-per-scene.mp4`. Gate green: 146/146 unit + 2/2 media incl. repeat-determinism.
- P1.3: shipped the ElevenLabs BYOK adapter (`eleven_multilingual_v2`, "any language" mode) — key only via injectable provider/env (never in metadata, logs, or errors), hard per-job character budget enforced before any paid call, retry with backoff on 429/5xx, fail-closed on auth errors, character usage returned as the UsageRecord prototype; explicit `narrationProvider: "elevenlabs"` selection wired into the narration selector. Mock-HTTP TDD (7 tests); live smoke pending an API key. Gate green: 141/141 unit + 2/2 media.

## 2026-07-13

- Locked the Board-only North Star, content pipeline, media architecture, delivery plan, agent orchestration and readiness ledger.
- Completed GitHub/open-source and model-routing research; adopted raw FFmpeg first and kept renderer/model providers behind Board-owned contracts.
- Added CSP/card-image XSS hardening and browser regression coverage.
- Built the R1 real-media vertical:
  - validated board JSON → deterministic storyboard/script;
  - provider-neutral TTS adapter with real offline WAV smoke output;
  - SRT generation and measured timeline reconciliation;
  - real 1920×1080 and 1080×1920 H.264/AAC MP4 rendering;
  - strict ffprobe/codec/duration/size QC;
  - deterministic manifest, hashes, redacted argv and SHA-256 sidecar.
- Hardened imported-input resource limits, normalized ID collisions, private output roots, atomic artifacts, plaintext cleanup, scrubbed media subprocess env, cancellation and timeout escalation.
- Added repeat-render reproducibility checks and made `test:media` part of `npm run check`.
- Independent follow-up review blocked snapshot `32f8813` on four residual counterexamples; all four now have regressions and fixes:
  - iterative depth/node/array/string/cycle preflight before any CLI/render side effect;
  - fail-closed command evidence plus Authorization/header/credential-URL redaction;
  - direct independent `/usr/bin/ffprobe` checks of MP4 and WAV;
  - four reproducibility renders across both aspect ratios and removal of repository `tmp` from trusted roots.
- Verified the post-review `npm run check`: 88/88 unit tests, API smoke, four real FFmpeg/ffprobe renders, Vite build and browser screenshot smoke.
- Independent re-review of `bef0a66` returned 6 PASS / 1 BLOCK: attached header flags, username-only credential URLs and cookie args could still enter manifest evidence.
- Replaced permissive command evidence with exact `tts` and `render` FFmpeg argv schemas; all reviewer sentinels now fail closed and both real aspect-ratio integrations pass.
- Added the R2 local Board worker and UI:
  - loopback/same-origin HTTP boundary with a required mutation header and bounded JSON bodies;
  - one-at-a-time bounded render queue, cancellation and private path redaction;
  - allowlisted artifact downloads and cleanup when completed jobs are evicted;
  - Board controls for recipe selection, status, cancellation and artifact links.
- Verified the R2 merged branch `npm run check`: 98/98 unit tests, API smoke, four real repeat renders, build and browser smoke.
- Added the R3 connector capability contract:
  - shared normalization of the existing 44-provider catalog;
  - Board-owned runtime adapter routes with primary/fallback/blockers;
  - secret-free capability status API and agent-plan integration;
  - fail-closed distinction between configured credentials, implemented adapter and executable route;
  - social publishing remains OAuth/immutable-approval blocked.
- Verified the R3 combined `npm run check`: 102/102 unit tests, API smoke, four real FFmpeg/ffprobe renders, Vite build and browser screenshot smoke.
- Added the R4 immutable publish candidate contract:
  - deterministic project/recipe/artifact/manifest/rights/evidence digest and sealed ID;
  - metadata-only public create/list/read routes with workspace isolation and idempotency;
  - exact candidate ID/digest/version approval binding and stale digest rejection;
  - approved-but-execution-blocked jobs cannot be relabelled running through PATCH;
  - local worker persistence of server-verified evidence remains the next blocker.
- Verified the R4 combined `npm run check`: 107/107 unit tests, API smoke, four real FFmpeg/ffprobe renders, Vite build and browser screenshot smoke.
- Ollama `kimi-k2.7-code:cloud` + OpenCode launcher and handoff are committed; parallel Kimi execution is blocked only by pending owner `ollama signin`.
- Verified a real local HTTP job produced and downloaded a 15.97-second 1920×1080 H.264/AAC MP4; public job state contained no `/tmp` path.
- Verified the public CLI manually produced a 15.96-second 1920×1080 H.264/AAC file and valid manifest sidecar.
- Claude Code remains installed but unauthenticated; mandatory Claude Opus review is a documented pending gate rather than a claimed pass.

## 2026-07-08

- Added an account-auth foundation:
  - `auth/status`, `auth/signup`, `auth/login`, and `auth/logout` product routes;
  - `users` storage collection;
  - scrypt password hashing and redacted account responses;
  - httpOnly signed `hermest_session` cookie issuance;
  - in-board Settings controls for account status, signup, login, and logout;
  - unit and smoke coverage for disabled auth, signup, login, duplicate email,
    invalid credentials, session cookies, and account-owned project writes.

## 2026-07-03

- Hardened temporary public demo storage:
  - owner-token protection now covers project, asset, job, and audit read routes when `HERMEST_ENABLE_DEMO_STORAGE=1` on Vercel;
  - external durable-storage env presence is smoke-tested to stay guarded until a real adapter/auth/authorization layer exists;
  - API smoke coverage now checks demo-storage read guards and owner-token authenticated reads.
- Aligned asset rights metadata with the durable schema:
  - `rightsStatus` now accepts only `unknown`, `allowed`, `restricted`, `owned`, or `generated`;
  - API smoke coverage rejects invalid asset rights status values before storage.
- Reactivated Fable 5 Ultracode handoff with hourly waiting mode and disabled Codex auto-resume to avoid agent conflicts.
- Added product preflight readiness route for durable storage, auth, connector, job, and autopublishing blockers.
- Added a storage adapter boundary while keeping the current `json-file` adapter guarded for public Vercel.
- Added project ownership metadata fields for the future workspace/user authorization layer while preserving existing ownership on updates.
- Added current-session API contract for bootstrap actor metadata ahead of real per-user auth.
- Added signed session token verification foundation without adding a public token issuer or enabling production writes.
- Added an owner-token gated signed-session bootstrap issuer for controlled demo/migration tokens without enabling public auth.
- Added signed-session project authorization checks against bootstrap `workspaceId`.
- Added signed OAuth state generation and callback validation guards for connector routes while keeping token exchange disabled.
- Added encrypted connector token vault storage with redacted API responses and smoke coverage against plaintext token leaks.
- Extended bootstrap signed-session workspace authorization to asset and job records:
  - new assets/jobs inherit project ownership metadata when linked to a project;
  - signed-session list/read/update paths are filtered or rejected by `workspaceId`;
  - API smoke coverage now verifies cross-workspace denial for projects, assets, and jobs.
- Added workspace ownership metadata and signed-session filtering for audit records.
- Added a guarded `postgres-jsonb` storage adapter foundation:
  - adapter stays inactive on public Vercel unless `HERMEST_STORAGE_ADAPTER=postgres` and `HERMEST_ENABLE_DURABLE_STORAGE=1` are set;
  - durable writes remain blocked without `HERMEST_OWNER_TOKEN` or `HERMEST_SESSION_SECRET`;
  - preflight now separates durable adapter implementation, configuration, and enablement.
- Hardened agent job status handling:
  - aligned API-created approval jobs with the durable schema status `waiting_for_approval`;
  - rejected invalid job status updates;
  - extended API smoke coverage for blocked jobs, approval-gated jobs, and invalid status PATCH requests.
- Added a human approval decision endpoint for jobs while keeping execution blocked until durable approval-gated workers exist.
- Added in-board BYOK AI settings and `/api/ai/respond`:
  - users can enter their own OpenAI API key in the board UI;
  - keys are not included in project JSON, backend project saves, source zip, or repository code;
  - API smoke coverage verifies missing-key rejection and mocked OpenAI proxy behavior without a real key.
- Expanded the AI entrypoint into a general Settings button:
  - OpenAI BYOK remains the working AI path;
  - browser-only slots now exist for future parser/media/translation/workflow keys;
  - user config schema documents browser-only user keys separately from hidden owner/server secrets.
- Added a broad API provider catalog:
  - 40+ provider slots across AI, search, media, speech, social publishing, automation, storage, email, and payments;
  - catalog stores official docs/signup links and free/no-key metadata, not API secrets;
  - settings UI can filter providers by category, open official docs, activate no-key sources, and store user-owned keys locally.
- Expanded `/api/ai/respond` beyond OpenAI:
  - OpenAI still uses the Responses API;
  - Groq, Mistral, OpenRouter, DeepSeek, and Together AI use chat-completions style BYOK requests;
  - smoke coverage checks both OpenAI Responses and Groq-compatible paths without real keys.
- Added an in-board `1.0 статус` readiness report:
  - fetches `/api/product?route=preflight`;
  - formats gates, connector config, blockers, and next required work in the publish output area;
  - keeps alpha/demo mode explicit until storage, auth, OAuth, jobs, and approval-gated workers are complete.
- Expanded no-key public research:
  - added Wikidata, Wikimedia Commons, and Open Library search;
  - added per-provider timeout so slow public APIs do not block the whole research response.
- Verified local project is its own clean git repo on `main`.
- Verified GitHub `origin/main` matches local commit `bef87cb`.
- Verified public production endpoints are live:
  - `GET /api/health`
  - `GET /api/connectors/status`
  - `GET /api/public/sources`
  - source zip download under `/download/hermest-board-alpha-source.zip`
- Added backend API contracts behind one Vercel Hobby-safe endpoint:
  - storage status;
  - projects;
  - assets;
  - jobs;
  - audit;
  - agent plan preview.
- Added safe JSON-file storage adapter for local development.
- Blocked unsafe public Vercel writes unless demo storage is explicitly enabled.
- Connected UI buttons for storage status, API save/load, and backend agent plan.
- Updated product readiness, architecture, deployment, and API docs.
- Added Fable handoff and roadmap documentation for continuing the project toward 1.0.0.
- Added bootstrap owner-token write guard and API smoke checks for product routes.
- Added first Postgres schema draft for durable storage/auth phase.
- Added runnable draft SQL at `db/postgres-schema.sql`.
- Added Fable 5 Ultracode maximum upgrade mandate with official standards references.
- Confirmed Fable auto-resume created infrastructure but no product commits; paused the timer to avoid more limit burn and agent conflicts.
- Added a security review baseline, CSP/COOP headers, and a live production verification script.
- Added P2.8 music bed with auto-ducking: local CC0 library port, sidechaincompress mix in composed renders, music provenance in manifest, UI toggle; fixed ffmpeg threaded-scheduler nondeterminism via asetnsamples (4/4 identical renders verified).
- Fixed transparent overlay scene-frame argv schema gap (builder emitted --default-background-color=00000000, manifest validator rejected it — path was dormant until a live Pexels key arrived). First full-stack renders shipped: ElevenLabs voice (Aterna/George) + live Pexels b-roll (2 clips) + ducked music bed, zero warnings; samples in ~/Видео/hermest-board-ads/samples/ru-fullstack-{aterna,george}.mp4. Pexels + FAL keys registered in ~/.secrets/env.sh (FAL pending P2.2 adapter).
